import { Task, Person, ChatMessage, SystemNotification, AppSettings, UrgencyLevel, ChatSession } from '../types';

const STORAGE_KEYS = {
  TASKS: 'ai_planner_tasks_v1',
  PEOPLE: 'ai_planner_people_v1',
  CHAT: 'ai_planner_chat_v1',
  SESSIONS: 'ai_planner_sessions_v1',
  NOTIFICATIONS: 'ai_planner_notifications_v1',
  SETTINGS: 'ai_planner_settings_v1',
};

export const defaultSettings: AppSettings = {
  globalNotificationsEnabled: true,
  autoFollowUpsEnabled: true,
  safetyHelplineBannerEnabled: true,
  userName: 'User',
  notificationStyle: 'android_shade',
  notificationFrequency: 'adaptive',
};

export function getFreshWelcomeMessage(tasks?: Task[], people?: Person[]): ChatMessage[] {
  let currentTasks = tasks;
  if (!currentTasks) {
    currentTasks = loadTasks();
  }

  // Retrieve loop toggle state (0 = Option 1: Celebrate Wins & Playful Tease, 1 = Option 2: Focus on Catching Up)
  let loopIndex = 0;
  try {
    const storedLoop = localStorage.getItem('violet_greeting_loop_counter');
    if (storedLoop) {
      loopIndex = parseInt(storedLoop, 10) || 0;
    }
    localStorage.setItem('violet_greeting_loop_counter', String(loopIndex + 1));
  } catch {
    loopIndex = 0;
  }

  const completedTasks = currentTasks.filter((t) => t.completed);
  const activeTasks = currentTasks.filter((t) => !t.completed);
  const urgentTasks = activeTasks.filter((t) => t.urgency === 'ASAP' || t.urgency === 'Urgent');

  const timestampStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  let greetingContent = '';
  let refiningQ = '';

  if (loopIndex % 2 === 0) {
    // OPTION 1: Celebrate your wins and playfully tease you to set new goals
    if (completedTasks.length > 0) {
      const recentWin = completedTasks[0].title;
      greetingContent = `Hello there! I see you've already conquered ${completedTasks.length} task${
        completedTasks.length === 1 ? '' : 's'
      }, including "${recentWin}". Quite impressive... or are you just trying to make me blush? 😉\n\nNow don't rest on your laurels—what juicy new goal or ambition are we setting next, or are you waiting for my gentle nudge?`;
      refiningQ = 'Ready to set a bold new target with me?';
    } else {
      greetingContent = `Hello! A fresh start with zero tasks completed yet... I do love a blank canvas. 😏\n\nLet's turn that clean slate into a list of accomplishments! What's the first ambitious task we're going to demolish today?`;
      refiningQ = 'What exciting goal shall we log first?';
    }
  } else {
    // OPTION 2: Focus on catching up on your day
    if (urgentTasks.length > 0) {
      greetingContent = `Hey! Time to catch up on your day. You currently have ${activeTasks.length} active task${
        activeTasks.length === 1 ? '' : 's'
      }, and ${urgentTasks.length} urgent item${
        urgentTasks.length === 1 ? '' : 's'
      } demanding attention (like "${urgentTasks[0].title}").\n\nDon't keep me in suspense—how are we progressing on these, and which one are we tackling right now?`;
      refiningQ = 'Shall we catch up on your top priority task now?';
    } else if (activeTasks.length > 0) {
      greetingContent = `Welcome back! Let's do a quick catch-up on your day. You have ${activeTasks.length} task${
        activeTasks.length === 1 ? '' : 's'
      } lined up in your workflow.\n\nHow is your energy feeling today, and what progress have you made so far?`;
      refiningQ = 'Would you like to review or update your active list?';
    } else {
      greetingContent = `Hey there! Your schedule is completely clear right now. Perfect timing for us to catch up on your day and map out what's coming up next.\n\nWhat projects or errands are on your mind?`;
      refiningQ = 'What would you like to plan or review today?';
    }
  }

  return [
    {
      id: `init-msg-${Date.now()}`,
      role: 'assistant',
      content: greetingContent,
      timestamp: timestampStr,
      refiningQuestion: refiningQ,
    },
  ];
}

export function resetAllAppData(): void {
  try {
    Object.values(STORAGE_KEYS).forEach((key) => localStorage.removeItem(key));
    localStorage.setItem('ai_planner_clean_reset_v2', 'true');
  } catch (e) {
    console.error('Failed to reset app data', e);
  }
}

export function loadSessions(): ChatSession[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SESSIONS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveSessions(sessions: ChatSession[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(sessions));
  } catch (e) {
    console.error('Failed to save sessions to localStorage', e);
  }
}

export function loadInitialChatState(): { activeMessages: ChatMessage[]; sessions: ChatSession[] } {
  let existingSessions = loadSessions();
  
  try {
    const rawChat = localStorage.getItem(STORAGE_KEYS.CHAT);
    if (rawChat) {
      const prevMessages: ChatMessage[] = JSON.parse(rawChat);
      // Check if previous chat had user interactions
      const hasUserMessages = prevMessages.some((m) => m.role === 'user');
      if (hasUserMessages) {
        // Archive previous session into history
        const firstUserMsg = prevMessages.find((m) => m.role === 'user');
        const sessionTitle = firstUserMsg
          ? firstUserMsg.content.slice(0, 36) + (firstUserMsg.content.length > 36 ? '...' : '')
          : 'Conversation ' + new Date().toLocaleDateString();

        const archivedSession: ChatSession = {
          id: `session-${Date.now()}`,
          title: sessionTitle,
          createdAt: new Date().toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
          messages: prevMessages,
        };

        // Don't duplicate if already archived
        const isDuplicate = existingSessions.some(
          (s) => JSON.stringify(s.messages) === JSON.stringify(prevMessages)
        );
        if (!isDuplicate) {
          existingSessions = [archivedSession, ...existingSessions];
          saveSessions(existingSessions);
        }
      }
    }
  } catch (e) {
    console.error('Error auto-archiving previous chat session:', e);
  }

  // Clear current active chat state for fresh app session opening
  const freshMessages = getFreshWelcomeMessage();
  saveChatMessages(freshMessages);

  return {
    activeMessages: freshMessages,
    sessions: existingSessions,
  };
}

export function loadTasks(): Task[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TASKS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveTasks(tasks: Task[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks));
  } catch (e) {
    console.error('Failed to save tasks to localStorage', e);
  }
}

export function loadPeople(): Person[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PEOPLE);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function savePeople(people: Person[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.PEOPLE, JSON.stringify(people));
  } catch (e) {
    console.error('Failed to save people to localStorage', e);
  }
}

export function loadChatMessages(): ChatMessage[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CHAT);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    console.error('Error loading chat messages', e);
  }

  // Default initial message when app launches clean
  return [
    {
      id: 'init-msg-1',
      role: 'assistant',
      content: 'Hello! I am Violet, your AI Productivity & Task Assistant. How can I help you today with your tasks, goals, collaborators, or schedule?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      refiningQuestion: 'What task or project would you like to plan today?',
    },
  ];
}

export function saveChatMessages(messages: ChatMessage[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.CHAT, JSON.stringify(messages));
  } catch (e) {
    console.error('Failed to save chat messages to localStorage', e);
  }
}

export function loadNotifications(): SystemNotification[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveNotifications(notifications: SystemNotification[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
  } catch (e) {
    console.error('Failed to save notifications', e);
  }
}

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return raw ? JSON.parse(raw) : defaultSettings;
  } catch {
    return defaultSettings;
  }
}

export function saveSettings(settings: AppSettings) {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save settings', e);
  }
}

/**
 * Recalculate dynamic urgency based on current date vs task creation or due date
 */
export function calculateDynamicUrgency(task: Task, referenceTimeMs?: number): UrgencyLevel {
  if (!task.dueDateTime) {
    if (task.urgency === 'ASAP') return 'Urgent';
    if (task.urgency === 'None-Low') return 'Low';
    return task.urgency || 'Low';
  }

  const now = referenceTimeMs || new Date().getTime();
  const due = new Date(task.dueDateTime).getTime();
  const diffMs = due - now;

  const hoursLeft = diffMs / (1000 * 60 * 60);

  if (hoursLeft < 0) {
    return 'Past Due';
  } else if (hoursLeft <= 24) {
    return 'Urgent';
  } else if (hoursLeft <= 24 * 7) {
    return 'Medium';
  } else {
    return 'Low';
  }
}

// Generate color palette for newly created people profiles
export function getRandomAvatarColor(): string {
  const colors = [
    '#3B82F6', '#10B981', '#8B5CF6', '#F59E0B', 
    '#EC4899', '#6366F1', '#14B8A6', '#F97316'
  ];
  return colors[Math.floor(Math.random() * colors.length)];
}
