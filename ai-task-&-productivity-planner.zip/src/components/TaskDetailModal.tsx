import React, { useState } from 'react';
import {
  X,
  CheckCircle2,
  Clock,
  Bell,
  BellOff,
  Plus,
  Trash2,
  User,
  Tag,
  AlertTriangle,
  Smile,
  Globe,
  FileText,
  Calendar,
  Search,
} from 'lucide-react';
import { Task, Person, UrgencyLevel, EnvironmentalCategory } from '../types';
import { getRandomAvatarColor } from '../utils/storage';
import { CustomDropdown, DropdownOption } from './CustomDropdown';

interface TaskDetailModalProps {
  task: Task;
  people: Person[];
  onClose: () => void;
  onUpdateTask: (updatedTask: Task) => void;
  onDeleteTask: (taskId: string) => void;
  onAddNewPerson?: (newPerson: Partial<Person>) => Person | void;
}

const URGENCY_OPTIONS: DropdownOption<UrgencyLevel>[] = [
  { value: 'Low', label: 'Low Urgency', emoji: '🌱' },
  { value: 'Medium', label: 'Medium Urgency', emoji: '📅' },
  { value: 'Urgent', label: 'Urgent (< 24 Hours)', emoji: '🔥' },
  { value: 'Past Due', label: 'Past Due', emoji: '⚠️' },
];

const CATEGORY_OPTIONS: DropdownOption<EnvironmentalCategory>[] = [
  { value: 'Work', label: 'Work', emoji: '💼' },
  { value: 'College/School', label: 'College/School', emoji: '🎓' },
  { value: 'Self Growth', label: 'Self Growth', emoji: '🪴' },
  { value: 'Home & Family', label: 'Home & Family', emoji: '🏠' },
  { value: 'Health & Fitness', label: 'Health & Fitness', emoji: '🏋️' },
  { value: 'Finance', label: 'Finance', emoji: '💰' },
  { value: 'Social & Relationships', label: 'Social & Relationships', emoji: '🤝' },
  { value: 'Creative', label: 'Creative', emoji: '🎨' },
  { value: 'Errands & Admin', label: 'Errands & Admin', emoji: '📋' },
  { value: 'Side Project', label: 'Side Project', emoji: '🚀' },
  { value: 'Travel & Leisure', label: 'Travel & Leisure', emoji: '✈️' },
  { value: 'Hobbies & Leisure', label: 'Hobbies & Leisure', emoji: '🎨' },
];

const FOLLOWUP_OPTIONS: DropdownOption[] = [
  { value: 'auto', label: 'Auto (Adaptive based on Urgency)', emoji: '🤖' },
  { value: 'hourly', label: 'Hourly Check-ins', emoji: '⏱️' },
  { value: 'daily', label: 'Daily Check-ins', emoji: '☀️' },
  { value: 'weekly', label: 'Weekly Check-ins', emoji: '📅' },
  { value: 'none', label: 'Disabled for this task', emoji: '🚫' },
];

const EMOTIONAL_SUGGESTIONS = [
  'Exciting',
  'High Focus',
  'Routine',
  'Stressful',
  'Fulfilling',
  'Dreading',
  'Creative',
  'Relaxing',
];

export const TaskDetailModal: React.FC<TaskDetailModalProps> = ({
  task,
  people,
  onClose,
  onUpdateTask,
  onDeleteTask,
  onAddNewPerson,
}) => {
  const [title, setTitle] = useState(task.title);
  const [completed, setCompleted] = useState(task.completed);
  const [urgency, setUrgency] = useState<UrgencyLevel>(task.urgency);
  const [environmentalCategory, setEnvironmentalCategory] = useState<EnvironmentalCategory>(
    task.environmentalCategory
  );
  const [intendedTimeMinutes, setIntendedTimeMinutes] = useState(task.intendedTimeMinutes || 30);
  const [actualTimeMinutes, setActualTimeMinutes] = useState(task.actualTimeMinutes || 0);
  const [dueDateTime, setDueDateTime] = useState(task.dueDateTime || '');
  const [emotionalKeywords, setEmotionalKeywords] = useState<string[]>(
    task.emotionalKeywords || []
  );
  const [newKeyword, setNewKeyword] = useState('');
  const [notesBullets, setNotesBullets] = useState<string[]>(task.notesBullets || []);
  const [newNote, setNewNote] = useState('');
  const [involvedPeopleIds, setInvolvedPeopleIds] = useState<string[]>(
    task.involvedPeopleIds || []
  );
  const [notificationsEnabled, setNotificationsEnabled] = useState(task.notificationsEnabled);
  const [followUpFrequency, setFollowUpFrequency] = useState(task.followUpFrequency || 'auto');

  // People narrow-down & inline create state
  const [personSearchQuery, setPersonSearchQuery] = useState('');
  const [showAddPersonForm, setShowAddPersonForm] = useState(false);
  const [newPersonName, setNewPersonName] = useState('');
  const [newPersonRole, setNewPersonRole] = useState('');
  const [newPersonPhone, setNewPersonPhone] = useState('');

  const handleSave = () => {
    onUpdateTask({
      ...task,
      title,
      completed,
      urgency,
      environmentalCategory,
      intendedTimeMinutes: Number(intendedTimeMinutes),
      actualTimeMinutes: Number(actualTimeMinutes),
      dueDateTime: dueDateTime || null,
      emotionalKeywords,
      notesBullets,
      involvedPeopleIds,
      notificationsEnabled,
      followUpFrequency,
      completedAt: completed && !task.completed ? new Date().toISOString() : task.completedAt,
    });
    onClose();
  };

  const handleAddKeyword = (kw: string) => {
    const trimmed = kw.trim();
    if (!trimmed) return;
    if (!emotionalKeywords.includes(trimmed)) {
      setEmotionalKeywords([...emotionalKeywords, trimmed]);
    }
    setNewKeyword('');
  };

  const handleRemoveKeyword = (kw: string) => {
    setEmotionalKeywords(emotionalKeywords.filter((k) => k !== kw));
  };

  const handleAddNote = () => {
    if (!newNote.trim()) return;
    setNotesBullets([...notesBullets, newNote.trim()]);
    setNewNote('');
  };

  const handleRemoveNote = (index: number) => {
    setNotesBullets(notesBullets.filter((_, i) => i !== index));
  };

  const togglePersonLink = (personId: string) => {
    if (involvedPeopleIds.includes(personId)) {
      setInvolvedPeopleIds(involvedPeopleIds.filter((id) => id !== personId));
    } else {
      setInvolvedPeopleIds([...involvedPeopleIds, personId]);
    }
  };

  const handleCreateInlinePerson = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPersonName.trim()) return;

    if (onAddNewPerson) {
      const created = onAddNewPerson({
        name: newPersonName.trim(),
        roleOrRelation: newPersonRole.trim() || 'Collaborator',
        phone: newPersonPhone.trim() || undefined,
        avatarColor: getRandomAvatarColor(),
      });

      if (created && created.id) {
        setInvolvedPeopleIds((prev) => [...prev, created.id]);
      }
    }

    setNewPersonName('');
    setNewPersonRole('');
    setNewPersonPhone('');
    setShowAddPersonForm(false);
  };

  const filteredPeople = people.filter(
    (p) =>
      p.name.toLowerCase().includes(personSearchQuery.toLowerCase()) ||
      p.roleOrRelation?.toLowerCase().includes(personSearchQuery.toLowerCase()) ||
      p.aliases?.some((a) => a.toLowerCase().includes(personSearchQuery.toLowerCase()))
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto font-sans">
      <div className="bg-white rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 my-8">
        {/* Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-slate-900 via-slate-800 to-violet-950 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setCompleted(!completed)}
              className={`w-6 h-6 rounded-lg flex items-center justify-center transition-colors border cursor-pointer ${
                completed
                  ? 'bg-emerald-500 border-emerald-400 text-white'
                  : 'bg-white/10 border-white/20 hover:bg-white/20'
              }`}
            >
              {completed && <CheckCircle2 className="w-4 h-4" />}
            </button>
            <span className="text-xs font-bold uppercase tracking-wider text-violet-300">
              {completed ? 'Completed Task' : 'Active Task Details'}
            </span>
          </div>

          <button
            onClick={onClose}
            className="text-slate-300 hover:text-white p-1.5 rounded-full hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Past Due Banner */}
          {(task.completedPastDue || (completed && dueDateTime && new Date(dueDateTime).getTime() < Date.now())) && (
            <div className="bg-amber-50 border border-amber-200/90 rounded-2xl p-3 flex items-center gap-2.5 text-xs text-amber-900 font-medium">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>This activity was completed past due.</span>
            </div>
          )}

          {!completed && dueDateTime && new Date(dueDateTime).getTime() < Date.now() && (
            <div className="bg-rose-50 border border-rose-200/90 rounded-2xl p-3 flex items-center gap-2.5 text-xs text-rose-900 font-medium">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>This task is past due and requires immediate attention.</span>
            </div>
          )}
          {/* Task Title */}
          <div>
            <label className="text-xs font-bold text-slate-600 uppercase tracking-wider block mb-1">
              Task Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 text-slate-800 text-base font-bold rounded-2xl p-3 outline-none focus:border-violet-600 focus:bg-white transition-all"
            />
          </div>

          {/* Urgency & Category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <CustomDropdown
              label="Urgency Level"
              options={URGENCY_OPTIONS}
              value={urgency}
              onChange={(val) => setUrgency(val as UrgencyLevel)}
            />

            <CustomDropdown
              label="Environmental Realm"
              options={CATEGORY_OPTIONS}
              value={environmentalCategory}
              onChange={(val) => setEnvironmentalCategory(val as EnvironmentalCategory)}
            />
          </div>

          {/* Time Tracking & Metrics */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 space-y-3">
            <h4 className="text-xs font-bold text-slate-600 uppercase tracking-wider flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-violet-600" /> Time Metrics (Planned vs Actual)
            </h4>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] text-slate-500 font-medium block mb-1">
                  Intended Duration (mins)
                </label>
                <input
                  type="number"
                  min="0"
                  value={intendedTimeMinutes}
                  onChange={(e) => setIntendedTimeMinutes(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full bg-white border border-slate-200 text-slate-800 text-xs font-semibold rounded-xl p-2 outline-none focus:border-violet-600"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500 font-medium block mb-1">
                  Actual Spent Time (mins)
                </label>
                <input
                  type="number"
                  min="0"
                  value={actualTimeMinutes}
                  onChange={(e) => setActualTimeMinutes(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full bg-white border border-slate-200 text-slate-800 text-xs font-semibold rounded-xl p-2 outline-none focus:border-violet-600"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] text-slate-500 font-medium block mb-1 flex items-center gap-1">
                <Calendar className="w-3 h-3 text-slate-400" /> Target Due Date & Time
              </label>
              <input
                type="datetime-local"
                value={dueDateTime}
                onChange={(e) => setDueDateTime(e.target.value)}
                className="w-full bg-white border border-slate-200 text-slate-800 text-xs font-semibold rounded-xl p-2 outline-none focus:border-violet-600"
              />
            </div>
          </div>

          {/* Emotional Keywords */}
          <div>
            <label className="text-xs font-bold text-slate-600 uppercase tracking-wider block mb-1.5 flex items-center gap-1">
              <Smile className="w-3.5 h-3.5 text-pink-500" /> Emotional Mood & Keywords
            </label>
            <div className="flex flex-wrap gap-1.5 mb-2">
              {emotionalKeywords.map((kw) => (
                <span
                  key={kw}
                  className="text-xs bg-pink-50 text-pink-700 border border-pink-200 px-2.5 py-1 rounded-xl font-bold flex items-center gap-1"
                >
                  #{kw}
                  <button
                    type="button"
                    onClick={() => handleRemoveKeyword(kw)}
                    className="hover:text-red-600 cursor-pointer ml-0.5"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>

            {/* Quick Suggestions */}
            <div className="flex flex-wrap gap-1 mb-2">
              {EMOTIONAL_SUGGESTIONS.map((sug) => (
                <button
                  key={sug}
                  type="button"
                  onClick={() => handleAddKeyword(sug)}
                  className="text-[10px] bg-slate-100 hover:bg-slate-200 text-slate-600 px-2 py-0.5 rounded-lg font-semibold transition-colors cursor-pointer"
                >
                  + {sug}
                </button>
              ))}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={newKeyword}
                onChange={(e) => setNewKeyword(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddKeyword(newKeyword))}
                placeholder="Custom emotion/mindset keyword..."
                className="flex-1 bg-slate-50 border border-slate-200 text-xs p-2 rounded-xl outline-none focus:border-violet-600"
              />
              <button
                type="button"
                onClick={() => handleAddKeyword(newKeyword)}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold px-3 py-2 rounded-xl cursor-pointer"
              >
                Add
              </button>
            </div>
          </div>

          {/* Bullet Instructions & Notes */}
          <div>
            <label className="text-xs font-bold text-slate-600 uppercase tracking-wider block mb-1.5 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-violet-600" /> Key Instructions & Bullet Notes
            </label>
            {notesBullets.length > 0 && (
              <ul className="space-y-1.5 mb-2">
                {notesBullets.map((bullet, idx) => (
                  <li
                    key={idx}
                    className="flex items-start justify-between gap-2 bg-slate-50 border border-slate-200/80 p-2 rounded-xl text-xs text-slate-700"
                  >
                    <span className="flex-1">• {bullet}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveNote(idx)}
                      className="text-slate-400 hover:text-red-600 p-0.5 cursor-pointer"
                    >
                      ✕
                    </button>
                  </li>
                ))}
              </ul>
            )}
            <div className="flex gap-2">
              <input
                type="text"
                value={newNote}
                onChange={(e) => setNewNote(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddNote())}
                placeholder="Add instruction, detail to be attentive to, or note..."
                className="flex-1 bg-slate-50 border border-slate-200 text-xs p-2 rounded-xl outline-none focus:border-violet-600"
              />
              <button
                type="button"
                onClick={handleAddNote}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold px-3 py-2 rounded-xl cursor-pointer"
              >
                Add Bullet
              </button>
            </div>
          </div>

          {/* Involved People Link & Inline Creation */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block flex items-center gap-1">
                <User className="w-3.5 h-3.5 text-violet-600" /> Involved People
              </label>
              <button
                type="button"
                onClick={() => setShowAddPersonForm(!showAddPersonForm)}
                className="text-xs text-violet-700 bg-violet-100 hover:bg-violet-200 px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Quick Add Person
              </button>
            </div>

            {/* Inline Person Creation Form */}
            {showAddPersonForm && (
              <form onSubmit={handleCreateInlinePerson} className="p-3 bg-violet-50/90 border border-violet-200 rounded-2xl space-y-2 animate-in fade-in duration-150">
                <h5 className="text-xs font-bold text-violet-900">Add & Link New Person</h5>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input
                    type="text"
                    required
                    value={newPersonName}
                    onChange={(e) => setNewPersonName(e.target.value)}
                    placeholder="Full Name *"
                    className="bg-white border border-slate-200 text-xs text-slate-800 rounded-xl p-2 outline-none focus:border-violet-600 font-bold"
                  />
                  <input
                    type="text"
                    value={newPersonRole}
                    onChange={(e) => setNewPersonRole(e.target.value)}
                    placeholder="Role / Relation (e.g. Designer)"
                    className="bg-white border border-slate-200 text-xs text-slate-800 rounded-xl p-2 outline-none focus:border-violet-600"
                  />
                </div>
                <div className="flex items-center justify-between pt-1">
                  <input
                    type="text"
                    value={newPersonPhone}
                    onChange={(e) => setNewPersonPhone(e.target.value)}
                    placeholder="Phone or contact info (optional)"
                    className="bg-white border border-slate-200 text-xs text-slate-800 rounded-xl p-2 outline-none focus:border-violet-600 flex-1 mr-2"
                  />
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => setShowAddPersonForm(false)}
                      className="text-xs font-semibold text-slate-500 hover:text-slate-800 px-2 py-1"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs px-3 py-1.5 rounded-xl shadow-2xs cursor-pointer"
                    >
                      Save & Link
                    </button>
                  </div>
                </div>
              </form>
            )}

            {/* Narrow-down / Search People */}
            {people.length > 3 && (
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                <input
                  type="text"
                  value={personSearchQuery}
                  onChange={(e) => setPersonSearchQuery(e.target.value)}
                  placeholder="Narrow down existing collaborators..."
                  className="w-full bg-slate-50 border border-slate-200 text-xs text-slate-800 rounded-xl pl-8 pr-3 py-1.5 outline-none focus:border-violet-600"
                />
              </div>
            )}

            {people.length === 0 ? (
              <p className="text-xs text-slate-400 italic bg-slate-50 p-3 rounded-xl border border-slate-200">
                No people created yet. Click "+ Quick Add Person" above to add someone.
              </p>
            ) : (
              <div className="flex flex-wrap gap-2 pt-1 max-h-36 overflow-y-auto p-1">
                {filteredPeople.map((p) => {
                  const isLinked = involvedPeopleIds.includes(p.id);
                  return (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => togglePersonLink(p.id)}
                      className={`text-xs px-3 py-1.5 rounded-xl border font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                        isLinked
                          ? 'bg-violet-50 border-violet-300 text-violet-900 shadow-2xs'
                          : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      <span
                        className="w-2.5 h-2.5 rounded-full"
                        style={{ backgroundColor: p.avatarColor || '#7c3aed' }}
                      />
                      {p.name}
                      {isLinked && <span className="text-violet-600 font-bold">✓</span>}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Notifications & AI Follow-Up Controls */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h5 className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  {notificationsEnabled ? (
                    <Bell className="w-4 h-4 text-violet-600" />
                  ) : (
                    <BellOff className="w-4 h-4 text-slate-400" />
                  )}
                  In-App & Phone Notifications for Task
                </h5>
                <p className="text-[11px] text-slate-500">
                  Toggle whether reminders for this task display in app and notification shade
                </p>
              </div>
              <button
                type="button"
                onClick={() => setNotificationsEnabled(!notificationsEnabled)}
                className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                  notificationsEnabled ? 'bg-violet-600' : 'bg-slate-300'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-md absolute top-0.5 transition-transform ${
                    notificationsEnabled ? 'left-5.5' : 'left-0.5'
                  }`}
                />
              </button>
            </div>

            <CustomDropdown
              label="AI Automated Follow-Up Check-In Frequency"
              options={FOLLOWUP_OPTIONS}
              value={followUpFrequency}
              onChange={(val) => setFollowUpFrequency(val as any)}
            />
          </div>
        </div>

        {/* Modal Footer Actions */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between font-sans">
          <button
            type="button"
            onClick={() => onDeleteTask(task.id)}
            className="text-xs font-bold text-red-600 hover:text-red-700 hover:bg-red-50 px-3 py-2 rounded-xl transition-colors flex items-center gap-1 cursor-pointer"
          >
            <Trash2 className="w-4 h-4" /> Delete Task
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="text-xs font-bold text-slate-600 hover:bg-slate-200/60 px-4 py-2 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="text-xs font-bold bg-violet-600 hover:bg-violet-700 text-white px-5 py-2 rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              Save Changes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
