import React, { useState } from 'react';
import {
  CheckCircle2,
  Clock,
  Plus,
  Search,
  Filter,
  Bell,
  BellOff,
  User,
  Tag,
  AlertTriangle,
  Smile,
  ChevronRight,
  ChevronUp,
  ChevronDown,
  Minimize2,
  Maximize2,
  Sparkles,
} from 'lucide-react';
import { Task, Person, UrgencyLevel, EnvironmentalCategory } from '../types';
import { calculateDynamicUrgency, getRandomAvatarColor } from '../utils/storage';
import { CustomDropdown, DropdownOption } from './CustomDropdown';

interface TaskListViewProps {
  tasks: Task[];
  people: Person[];
  onSelectTask: (task: Task) => void;
  onToggleComplete: (taskId: string) => void;
  onToggleNotification: (taskId: string) => void;
  onAddNewTask: (newTask: Partial<Task>) => void;
  onAddNewPerson?: (newPerson: Partial<Person>) => Person | void;
  simulatedOffsetMs?: number;
}

const CATEGORIES: ('All' | EnvironmentalCategory)[] = [
  'All',
  'Work',
  'College/School',
  'Self Growth',
  'Home & Family',
  'Health & Fitness',
  'Finance',
  'Social & Relationships',
  'Creative',
  'Errands & Admin',
  'Side Project',
  'Travel & Leisure',
  'Hobbies & Leisure',
];

const URGENCY_OPTIONS: DropdownOption<UrgencyLevel>[] = [
  { value: 'Low', label: 'Low Urgency', emoji: '🌱' },
  { value: 'Medium', label: 'Medium Urgency', emoji: '📅' },
  { value: 'Urgent', label: 'Urgent (< 24h)', emoji: '🔥' },
  { value: 'Past Due', label: 'Past Due', emoji: '⚠️' },
];

const CATEGORY_OPTIONS: DropdownOption<EnvironmentalCategory>[] = [
  { value: 'Work', label: 'Work', emoji: '💼' },
  { value: 'College/School', label: 'College/School', emoji: '🎓' },
  { value: 'Self Growth', label: 'Self Growth', emoji: '🪴' },
  { value: 'Home & Family', label: 'Home & Family', emoji: '🏠' },
  { value: 'Health & Fitness', label: 'Health & Fitness', emoji: '🏋️' },
  { value: 'Finance', label: 'Finance', emoji: '💰' },
  { value: 'Social & Relationships', label: 'Social & Relationships', emoji: '🤝' },
  { value: 'Creative', label: 'Creative', emoji: '🎨' },
  { value: 'Errands & Admin', label: 'Errands & Admin', emoji: '📋' },
  { value: 'Side Project', label: 'Side Project', emoji: '🚀' },
  { value: 'Travel & Leisure', label: 'Travel & Leisure', emoji: '✈️' },
  { value: 'Hobbies & Leisure', label: 'Hobbies & Leisure', emoji: '🎨' },
];

export const TaskListView: React.FC<TaskListViewProps> = ({
  tasks,
  people,
  onSelectTask,
  onToggleComplete,
  onToggleNotification,
  onAddNewTask,
  onAddNewPerson,
  simulatedOffsetMs = 0,
}) => {
  const [selectedUrgency, setSelectedUrgency] = useState<string>('All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [minimizedTaskIds, setMinimizedTaskIds] = useState<Set<string>>(new Set());

  // Form states for manual add
  const [newTitle, setNewTitle] = useState('');
  const [newUrgency, setNewUrgency] = useState<UrgencyLevel>('Medium');
  const [newCategory, setNewCategory] = useState<EnvironmentalCategory>('Work');
  const [newIntendedMins, setNewIntendedMins] = useState(30);
  const [newInvolvedPeopleIds, setNewInvolvedPeopleIds] = useState<string[]>([]);

  // Inline Person creation in Quick Add
  const [showInlineAddPerson, setShowInlineAddPerson] = useState(false);
  const [inlinePersonName, setInlinePersonName] = useState('');
  const [inlinePersonRole, setInlinePersonRole] = useState('');

  const refTime = Date.now() + simulatedOffsetMs;

  const filteredTasks = tasks.filter((t) => {
    const dynamicUrgency = calculateDynamicUrgency(t, refTime);
    const matchesUrgency =
      selectedUrgency === 'All' ||
      dynamicUrgency === selectedUrgency ||
      (selectedUrgency === 'Urgent' && dynamicUrgency === 'ASAP') ||
      (selectedUrgency === 'Low' && dynamicUrgency === 'None-Low');
    const matchesCategory = selectedCategory === 'All' || t.environmentalCategory === selectedCategory;
    const matchesSearch =
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.notesBullets.some((n) => n.toLowerCase().includes(searchQuery.toLowerCase())) ||
      t.emotionalKeywords.some((k) => k.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesUrgency && matchesCategory && matchesSearch;
  });

  const toggleMinimizeTask = (taskId: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setMinimizedTaskIds((prev) => {
      const next = new Set(prev);
      if (next.has(taskId)) {
        next.delete(taskId);
      } else {
        next.add(taskId);
      }
      return next;
    });
  };

  const toggleMinimizeAll = () => {
    if (minimizedTaskIds.size === filteredTasks.length && filteredTasks.length > 0) {
      setMinimizedTaskIds(new Set());
    } else {
      setMinimizedTaskIds(new Set(filteredTasks.map((t) => t.id)));
    }
  };

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    onAddNewTask({
      title: newTitle.trim(),
      urgency: newUrgency,
      environmentalCategory: newCategory,
      intendedTimeMinutes: Number(newIntendedMins),
      actualTimeMinutes: 0,
      completed: false,
      emotionalKeywords: ['Focus'],
      notesBullets: [],
      involvedPeopleIds: newInvolvedPeopleIds,
      notificationsEnabled: true,
      followUpFrequency: 'auto',
      reminders: [],
    });

    setNewTitle('');
    setNewInvolvedPeopleIds([]);
    setShowAddModal(false);
  };

  const handleCreateInlinePerson = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inlinePersonName.trim()) return;

    if (onAddNewPerson) {
      const created = onAddNewPerson({
        name: inlinePersonName.trim(),
        roleOrRelation: inlinePersonRole.trim() || 'Collaborator',
        avatarColor: getRandomAvatarColor(),
      });

      if (created && created.id) {
        setNewInvolvedPeopleIds((prev) => [...prev, created.id]);
      }
    }

    setInlinePersonName('');
    setInlinePersonRole('');
    setShowInlineAddPerson(false);
  };

  const togglePersonSelect = (personId: string) => {
    if (newInvolvedPeopleIds.includes(personId)) {
      setNewInvolvedPeopleIds(newInvolvedPeopleIds.filter((id) => id !== personId));
    } else {
      setNewInvolvedPeopleIds([...newInvolvedPeopleIds, personId]);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 relative font-sans">
      {/* Top Header */}
      <div className="bg-white border-b border-slate-200 px-4 py-3 shrink-0 shadow-2xs">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-base font-bold text-slate-800">Task Inventory</h2>
            <p className="text-xs text-slate-500 font-medium">
              {filteredTasks.length} task{filteredTasks.length === 1 ? '' : 's'} shown • Categorized by Urgency & Realm
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={toggleMinimizeAll}
              className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
              title="Toggle minimize view on all tasks"
            >
              {minimizedTaskIds.size === filteredTasks.length && filteredTasks.length > 0 ? (
                <>
                  <Maximize2 className="w-3.5 h-3.5" /> Expand All
                </>
              ) : (
                <>
                  <Minimize2 className="w-3.5 h-3.5" /> Minimize All
                </>
              )}
            </button>

            <button
              onClick={() => setShowAddModal(true)}
              className="bg-violet-600 hover:bg-violet-700 text-white px-3.5 py-2 rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Add Task
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="relative mb-3">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search tasks by title, instructions, keywords, or people..."
            className="w-full bg-slate-100 focus:bg-white border border-slate-200 focus:border-violet-600 text-xs text-slate-800 rounded-xl pl-9 pr-3 py-2 outline-none transition-all"
          />
        </div>

        {/* Urgency Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1">Urgency:</span>
          {['All', 'Past Due', 'Urgent', 'Medium', 'Low'].map((urg) => (
            <button
              key={urg}
              onClick={() => setSelectedUrgency(urg)}
              className={`px-3 py-1 rounded-xl font-bold transition-all cursor-pointer shrink-0 ${
                selectedUrgency === urg
                  ? 'bg-slate-800 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {urg === 'Past Due'
                ? '⚠️ Past Due'
                : urg === 'Urgent'
                ? '🔥 Urgent'
                : urg === 'Medium'
                ? '📅 Medium'
                : urg === 'Low'
                ? '🌱 Low'
                : 'All'}
            </button>
          ))}
        </div>

        {/* Category Realm Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto pt-2 scrollbar-none text-xs">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded-lg font-semibold transition-all cursor-pointer shrink-0 ${
                selectedCategory === cat
                  ? 'bg-violet-600 text-white shadow-2xs'
                  : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Task List Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
        {filteredTasks.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-3xl p-8 text-center space-y-2 mt-4">
            <Sparkles className="w-8 h-8 text-violet-400 mx-auto" />
            <h3 className="text-sm font-bold text-slate-800">No matching tasks found</h3>
            <p className="text-xs text-slate-500 max-w-xs mx-auto">
              Type instructions into the Violet AI chat box or click "+ Add Task" to populate your workspace.
            </p>
          </div>
        ) : (
          filteredTasks.map((task) => {
            const dynamicUrgency = calculateDynamicUrgency(task, refTime);
            const isMinimized = minimizedTaskIds.has(task.id);
            const involvedPeople = people.filter((p) => task.involvedPeopleIds?.includes(p.id));
            const wasCompletedPastDue = task.completedPastDue || (task.completed && dynamicUrgency === 'Past Due');

            return (
              <div
                key={task.id}
                className={`bg-white border border-slate-200/90 rounded-2xl p-3.5 transition-all shadow-2xs hover:shadow-md ${
                  task.completed ? 'opacity-65 bg-slate-50/80' : ''
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  {/* Left: Checkbox & Info */}
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    <button
                      onClick={() => onToggleComplete(task.id)}
                      className={`mt-0.5 w-5 h-5 rounded-lg border flex items-center justify-center transition-colors shrink-0 cursor-pointer ${
                        task.completed
                          ? 'bg-emerald-500 border-emerald-500 text-white'
                          : 'border-slate-300 hover:border-violet-500 bg-slate-50'
                      }`}
                    >
                      {task.completed && <CheckCircle2 className="w-3.5 h-3.5" />}
                    </button>

                    <div className="min-w-0 flex-1 space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4
                          onClick={() => onSelectTask(task)}
                          className={`text-sm font-bold text-slate-800 hover:text-violet-600 transition-colors cursor-pointer ${
                            task.completed ? 'line-through text-slate-400' : ''
                          }`}
                        >
                          {task.title}
                        </h4>

                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-md font-extrabold uppercase tracking-wider flex items-center gap-1 ${
                            dynamicUrgency === 'Past Due'
                              ? 'bg-rose-100 text-rose-800 border border-rose-200/80'
                              : dynamicUrgency === 'Urgent' || dynamicUrgency === 'ASAP'
                              ? 'bg-amber-100 text-amber-800 border border-amber-200/80'
                              : dynamicUrgency === 'Medium'
                              ? 'bg-blue-100 text-blue-800 border border-blue-200/80'
                              : 'bg-emerald-100 text-emerald-800 border border-emerald-200/80'
                          }`}
                        >
                          {dynamicUrgency === 'Past Due' && '⚠️ '}
                          {dynamicUrgency === 'Urgent' || dynamicUrgency === 'ASAP' ? '🔥 ' : ''}
                          {dynamicUrgency === 'Medium' ? '📅 ' : ''}
                          {dynamicUrgency === 'Low' || dynamicUrgency === 'None-Low' ? '🌱 ' : ''}
                          {dynamicUrgency === 'ASAP' ? 'Urgent' : dynamicUrgency === 'None-Low' ? 'Low' : dynamicUrgency}
                        </span>

                        <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md font-bold">
                          {task.environmentalCategory}
                        </span>
                      </div>

                      {/* Completed Past Due Banner */}
                      {wasCompletedPastDue && (
                        <div className="mt-1 bg-amber-50/90 border border-amber-200/80 rounded-xl px-2.5 py-1 flex items-center gap-1.5 text-[11px] text-amber-900 font-medium">
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                          <span>Activity was completed past due</span>
                        </div>
                      )}

                      {/* Active Past Due Alert Banner */}
                      {!task.completed && dynamicUrgency === 'Past Due' && (
                        <div className="mt-1 bg-rose-50 border border-rose-200/90 rounded-xl px-2.5 py-1 flex items-center gap-1.5 text-[11px] text-rose-900 font-medium">
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                          <span>Overdue item — needs attention</span>
                        </div>
                      )}

                      {/* Minimized / Compact details */}
                      {!isMinimized && (
                        <div className="space-y-1.5 pt-1 animate-in fade-in duration-150">
                          {/* Notes Bullets */}
                          {task.notesBullets.length > 0 && (
                            <ul className="text-xs text-slate-600 space-y-0.5 pl-1">
                              {task.notesBullets.map((bullet, idx) => (
                                <li key={idx} className="flex items-start gap-1.5">
                                  <span className="text-violet-600 font-bold text-[10px]">•</span>
                                  <span>{bullet}</span>
                                </li>
                              ))}
                            </ul>
                          )}

                          {/* Involved People Badges */}
                          {involvedPeople.length > 0 && (
                            <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
                              <span className="text-[10px] font-bold text-slate-400 uppercase">People:</span>
                              {involvedPeople.map((p) => (
                                <span
                                  key={p.id}
                                  className="text-[11px] bg-violet-50 text-violet-900 border border-violet-200 px-2 py-0.5 rounded-lg font-bold flex items-center gap-1"
                                >
                                  <span
                                    className="w-2 h-2 rounded-full"
                                    style={{ backgroundColor: p.avatarColor || '#7c3aed' }}
                                  />
                                  {p.name}
                                </span>
                              ))}
                            </div>
                          )}

                          {/* Tags & Time */}
                          <div className="flex items-center gap-3 text-[11px] text-slate-500 pt-1">
                            <span className="flex items-center gap-1 font-semibold text-slate-600">
                              <Clock className="w-3 h-3 text-violet-600" />
                              {task.intendedTimeMinutes}m intended
                              {task.actualTimeMinutes > 0 && ` (${task.actualTimeMinutes}m spent)`}
                            </span>

                            {task.emotionalKeywords.length > 0 && (
                              <span className="text-pink-600 font-bold">
                                #{task.emotionalKeywords.join(', #')}
                              </span>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Actions & Minimize controls */}
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={(e) => toggleMinimizeTask(task.id, e)}
                      title={isMinimized ? 'Expand details' : 'Minimize card'}
                      className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                    >
                      {isMinimized ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
                    </button>

                    <button
                      onClick={() => onToggleNotification(task.id)}
                      title={
                        task.notificationsEnabled
                          ? 'Notifications enabled for this task'
                          : 'Notifications disabled for this task'
                      }
                      className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                        task.notificationsEnabled
                          ? 'text-violet-600 bg-violet-50 hover:bg-violet-100'
                          : 'text-slate-300 hover:text-slate-500'
                      }`}
                    >
                      {task.notificationsEnabled ? (
                        <Bell className="w-4 h-4" />
                      ) : (
                        <BellOff className="w-4 h-4" />
                      )}
                    </button>

                    <button
                      onClick={() => onSelectTask(task)}
                      className="p-1.5 text-slate-400 hover:text-violet-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                      title="Open full details"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Manual Quick Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md p-6 shadow-2xl space-y-4 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-800">Add New Task</h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-700 p-1 rounded-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="space-y-3 font-sans">
              <div>
                <label className="text-xs font-bold text-slate-600 block mb-1">Task Title <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g., Review project proposal with Sarah..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 font-bold outline-none focus:border-violet-600 focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <CustomDropdown
                  label="Urgency"
                  options={URGENCY_OPTIONS}
                  value={newUrgency}
                  onChange={(val) => setNewUrgency(val as UrgencyLevel)}
                />

                <CustomDropdown
                  label="Realm"
                  options={CATEGORY_OPTIONS}
                  value={newCategory}
                  onChange={(val) => setNewCategory(val as EnvironmentalCategory)}
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 block mb-1">
                  Intended Duration (Minutes)
                </label>
                <input
                  type="number"
                  value={newIntendedMins}
                  onChange={(e) => setNewIntendedMins(Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2 text-xs text-slate-800 font-sans outline-none focus:border-violet-600"
                />
              </div>

              {/* People Selection / Inline Add */}
              <div className="pt-2 border-t border-slate-100">
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-600">Assign People <span className="text-slate-400 text-[10px]">(Optional)</span></label>
                  <button
                    type="button"
                    onClick={() => setShowInlineAddPerson(!showInlineAddPerson)}
                    className="text-[11px] font-bold text-violet-700 hover:underline cursor-pointer"
                  >
                    + Quick Add Person
                  </button>
                </div>

                {showInlineAddPerson && (
                  <div className="p-2.5 bg-violet-50/80 border border-violet-200 rounded-xl space-y-2 mb-2">
                    <input
                      type="text"
                      value={inlinePersonName}
                      onChange={(e) => setInlinePersonName(e.target.value)}
                      placeholder="Full Name *"
                      className="w-full bg-white border border-slate-200 text-xs p-1.5 rounded-lg outline-none font-bold"
                    />
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={inlinePersonRole}
                        onChange={(e) => setInlinePersonRole(e.target.value)}
                        placeholder="Role / Relation (optional)"
                        className="flex-1 bg-white border border-slate-200 text-xs p-1.5 rounded-lg outline-none"
                      />
                      <button
                        type="button"
                        onClick={handleCreateInlinePerson}
                        className="bg-violet-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg cursor-pointer"
                      >
                        Save
                      </button>
                    </div>
                  </div>
                )}

                {people.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto pt-1">
                    {people.map((p) => {
                      const isSelected = newInvolvedPeopleIds.includes(p.id);
                      return (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => togglePersonSelect(p.id)}
                          className={`text-xs px-2.5 py-1 rounded-xl border font-bold flex items-center gap-1 transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-violet-50 border-violet-300 text-violet-900 shadow-2xs'
                              : 'bg-slate-50 border-slate-200 text-slate-600'
                          }`}
                        >
                          <span
                            className="w-2 h-2 rounded-full"
                            style={{ backgroundColor: p.avatarColor || '#7c3aed' }}
                          />
                          {p.name}
                          {isSelected && ' ✓'}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="text-xs font-bold text-slate-600 hover:bg-slate-100 px-4 py-2 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="text-xs font-bold bg-violet-600 hover:bg-violet-700 text-white px-5 py-2 rounded-xl shadow-xs cursor-pointer"
                >
                  Create Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
