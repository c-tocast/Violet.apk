import React, { useState } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  CartesianGrid,
  Legend,
} from 'recharts';
import {
  TrendingUp,
  Clock,
  Smile,
  Edit3,
  CheckCircle2,
  Sparkles,
  Sliders,
  MessageSquare,
} from 'lucide-react';
import { Task } from '../types';
import { calculateDynamicUrgency } from '../utils/storage';

interface AnalyticsViewProps {
  tasks: Task[];
  onUpdateTask: (updatedTask: Task) => void;
  onSendChatMessage?: (prompt: string) => void;
}

const COLORS = ['#3B82F6', '#10B981', '#8B5CF6', '#EC4899', '#F59E0B', '#6366F1', '#14B8A6'];

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  tasks,
  onUpdateTask,
  onSendChatMessage,
}) => {
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [manualIntended, setManualIntended] = useState<number>(30);
  const [manualActual, setManualActual] = useState<number>(30);
  const [manualKeyword, setManualKeyword] = useState<string>('');
  const [aiCustomPrompt, setAiCustomPrompt] = useState<string>('');

  // 1. Quantitative Data: Time by Environmental Realm
  const categoryTimeMap: Record<string, { realm: string; Intended: number; Actual: number }> = {};

  tasks.forEach((t) => {
    const realm = t.environmentalCategory || 'General';
    if (!categoryTimeMap[realm]) {
      categoryTimeMap[realm] = { realm, Intended: 0, Actual: 0 };
    }
    categoryTimeMap[realm].Intended += t.intendedTimeMinutes || 0;
    categoryTimeMap[realm].Actual += t.actualTimeMinutes || 0;
  });

  const quantitativeChartData = Object.values(categoryTimeMap);

  // 2. Qualitative Data: Tasks by Emotional Keywords
  const keywordCountMap: Record<string, number> = {};
  tasks.forEach((t) => {
    (t.emotionalKeywords || ['Uncategorized']).forEach((kw) => {
      keywordCountMap[kw] = (keywordCountMap[kw] || 0) + 1;
    });
  });

  const qualitativeChartData = Object.entries(keywordCountMap).map(([name, value]) => ({
    name,
    value,
  }));

  // Totals for header cards
  const totalIntendedMins = tasks.reduce((acc, t) => acc + (t.intendedTimeMinutes || 0), 0);
  const totalActualMins = tasks.reduce((acc, t) => acc + (t.actualTimeMinutes || 0), 0);
  const completedCount = tasks.filter((t) => t.completed).length;

  const handleStartEdit = (t: Task) => {
    setEditingTaskId(t.id);
    setManualIntended(t.intendedTimeMinutes || 30);
    setManualActual(t.actualTimeMinutes || 0);
    setManualKeyword(t.emotionalKeywords?.[0] || 'High Focus');
  };

  const handleSaveManual = (task: Task) => {
    onUpdateTask({
      ...task,
      intendedTimeMinutes: Number(manualIntended),
      actualTimeMinutes: Number(manualActual),
      emotionalKeywords: manualKeyword.trim()
        ? Array.from(new Set([...(task.emotionalKeywords || []), manualKeyword.trim()]))
        : task.emotionalKeywords,
    });
    setEditingTaskId(null);
  };

  const handleSendAiPrompt = () => {
    if (!aiCustomPrompt.trim()) return;
    if (onSendChatMessage) {
      onSendChatMessage(`Adjust my task analytics metrics: ${aiCustomPrompt}`);
      setAiCustomPrompt('');
    }
  };

  // Punctuality & Due Date Metrics
  const completedOnTime = tasks.filter((t) => t.completed && !t.completedPastDue).length;
  const completedPastDue = tasks.filter((t) => t.completed && t.completedPastDue).length;
  const activePastDue = tasks.filter((t) => !t.completed && calculateDynamicUrgency(t) === 'Past Due').length;
  const activeOnTrack = tasks.filter((t) => !t.completed && calculateDynamicUrgency(t) !== 'Past Due').length;

  const punctualityBarData = [
    { category: 'Completed On Time', count: completedOnTime, fill: '#10B981' },
    { category: 'Completed Past Due', count: completedPastDue, fill: '#F43F5E' },
    { category: 'Active On Track', count: activeOnTrack, fill: '#3B82F6' },
    { category: 'Active Overdue', count: activePastDue, fill: '#F59E0B' },
  ];

  return (
    <div className="flex flex-col h-full bg-slate-50 relative overflow-y-auto p-4 space-y-4">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200/90 rounded-3xl p-5 shadow-2xs">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-base font-bold text-slate-800 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-600" />
              Quantitative & Qualitative Completion Analytics
            </h2>
            <p className="text-xs text-slate-500">
              Measure planned vs actual durations, emotional category distribution, and punctuality performance.
            </p>
          </div>
        </div>

        {/* Overview Stats Row */}
        <div className="grid grid-cols-3 gap-2.5">
          <div className="bg-blue-50/70 border border-blue-100 rounded-2xl p-3">
            <span className="text-[10px] font-bold text-blue-700 uppercase tracking-wider block">
              Intended Duration
            </span>
            <span className="text-lg font-black text-blue-900 mt-0.5 block">
              {Math.round(totalIntendedMins / 60)}h {totalIntendedMins % 60}m
            </span>
          </div>

          <div className="bg-emerald-50/70 border border-emerald-100 rounded-2xl p-3">
            <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block">
              Actual Time Spent
            </span>
            <span className="text-lg font-black text-emerald-900 mt-0.5 block">
              {Math.round(totalActualMins / 60)}h {totalActualMins % 60}m
            </span>
          </div>

          <div className="bg-purple-50/70 border border-purple-100 rounded-2xl p-3">
            <span className="text-[10px] font-bold text-purple-700 uppercase tracking-wider block">
              Tasks Completed
            </span>
            <span className="text-lg font-black text-purple-900 mt-0.5 block">
              {completedCount} / {tasks.length}
            </span>
          </div>
        </div>
      </div>

      {/* Punctuality & Due Date Performance Comparison */}
      <div className="bg-white border border-slate-200/90 rounded-3xl p-5 shadow-2xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              Punctuality Analysis: On Time vs Past Due
            </h3>
            <p className="text-[11px] text-slate-500">
              Compare activities completed on time against those completed past due or currently overdue.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
          <div className="bg-emerald-50 border border-emerald-200/80 rounded-2xl p-3 text-center">
            <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block">Completed On Time</span>
            <span className="text-xl font-black text-emerald-900 mt-0.5 block">{completedOnTime}</span>
          </div>

          <div className="bg-rose-50 border border-rose-200/80 rounded-2xl p-3 text-center">
            <span className="text-[10px] font-bold text-rose-700 uppercase tracking-wider block">Completed Past Due</span>
            <span className="text-xl font-black text-rose-900 mt-0.5 block">{completedPastDue}</span>
          </div>

          <div className="bg-blue-50 border border-blue-200/80 rounded-2xl p-3 text-center">
            <span className="text-[10px] font-bold text-blue-700 uppercase tracking-wider block">Active On Track</span>
            <span className="text-xl font-black text-blue-900 mt-0.5 block">{activeOnTrack}</span>
          </div>

          <div className="bg-amber-50 border border-amber-200/80 rounded-2xl p-3 text-center">
            <span className="text-[10px] font-bold text-amber-700 uppercase tracking-wider block">Active Overdue</span>
            <span className="text-xl font-black text-amber-900 mt-0.5 block">{activePastDue}</span>
          </div>
        </div>

        <div className="h-48 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={punctualityBarData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
              <XAxis dataKey="category" tick={{ fontSize: 10, fill: '#64748B' }} />
              <YAxis tick={{ fontSize: 10, fill: '#64748B' }} allowDecimals={false} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1E293B', borderRadius: '12px', border: 'none', color: '#fff', fontSize: '12px' }}
              />
              <Bar dataKey="count" radius={[8, 8, 0, 0]} name="Task Count">
                {punctualityBarData.map((entry, index) => (
                  <Cell key={`cell-punc-${index}`} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 1. Quantitative Graph: Planned vs Actual Time */}
      <div className="bg-white border border-slate-200/90 rounded-3xl p-5 shadow-2xs space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-blue-600" />
            Quantitative Comparison: Intended vs Actual Time (Minutes)
          </h3>
        </div>

        {quantitativeChartData.length === 0 ? (
          <p className="text-xs text-slate-400 italic text-center py-6">
            No time metrics tracked yet. Add tasks or log time to populate quantitative graphs.
          </p>
        ) : (
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={quantitativeChartData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                <XAxis dataKey="realm" tick={{ fontSize: 10, fill: '#64748B' }} interval={0} angle={-15} textAnchor="end" />
                <YAxis tick={{ fontSize: 10, fill: '#64748B' }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1E293B', borderRadius: '12px', border: 'none', color: '#fff', fontSize: '12px' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                <Bar dataKey="Intended" fill="#3B82F6" radius={[6, 6, 0, 0]} name="Intended Duration (m)" />
                <Bar dataKey="Actual" fill="#10B981" radius={[6, 6, 0, 0]} name="Actual Spent (m)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* 2. Qualitative Graph: Emotional Keyword Breakdown */}
      <div className="bg-white border border-slate-200/90 rounded-3xl p-5 shadow-2xs space-y-3">
        <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
          <Smile className="w-4 h-4 text-pink-600" />
          Qualitative Breakdown: Tasks by Emotional Keywords
        </h3>

        {qualitativeChartData.length === 0 ? (
          <p className="text-xs text-slate-400 italic text-center py-6">
            No emotional keyword tags recorded yet. Tag tasks with keywords like #Exciting or #HighFocus.
          </p>
        ) : (
          <div className="h-56 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={qualitativeChartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {qualitativeChartData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#1E293B', borderRadius: '12px', border: 'none', color: '#fff', fontSize: '12px' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* 3. Manual Override for Greater Accuracy */}
      <div className="bg-white border border-slate-200/90 rounded-3xl p-5 shadow-2xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Sliders className="w-4 h-4 text-indigo-600" />
              Manual Value Adjustments for Accuracy
            </h3>
            <p className="text-[11px] text-slate-500">
              Override intended vs actual times or assign custom emotional keywords for greater precision.
            </p>
          </div>
        </div>

        {tasks.length === 0 ? (
          <p className="text-xs text-slate-400 italic text-center py-2">No tasks available to adjust.</p>
        ) : (
          <div className="space-y-2 max-h-60 overflow-y-auto">
            {tasks.map((task) => {
              const isEditing = editingTaskId === task.id;

              return (
                <div
                  key={task.id}
                  className="bg-slate-50 border border-slate-200 rounded-2xl p-3 text-xs space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800 truncate">{task.title}</span>
                    {!isEditing ? (
                      <button
                        onClick={() => handleStartEdit(task)}
                        className="text-blue-600 font-semibold hover:underline flex items-center gap-1"
                      >
                        <Edit3 className="w-3 h-3" /> Adjust
                      </button>
                    ) : (
                      <button
                        onClick={() => handleSaveManual(task)}
                        className="bg-blue-600 text-white font-bold px-3 py-1 rounded-lg hover:bg-blue-700"
                      >
                        Save
                      </button>
                    )}
                  </div>

                  {!isEditing ? (
                    <div className="flex items-center gap-3 text-slate-500 text-[11px]">
                      <span>Intended: {task.intendedTimeMinutes}m</span>
                      <span>•</span>
                      <span>Actual: {task.actualTimeMinutes}m</span>
                      <span>•</span>
                      <span className="text-pink-600 font-medium">
                        #{task.emotionalKeywords?.join(', #') || 'None'}
                      </span>
                    </div>
                  ) : (
                    <div className="grid grid-cols-3 gap-2 pt-1">
                      <div>
                        <label className="text-[10px] text-slate-500 block mb-0.5">Intended (m)</label>
                        <input
                          type="number"
                          value={manualIntended}
                          onChange={(e) => setManualIntended(Number(e.target.value))}
                          className="w-full bg-white border border-slate-200 rounded-lg p-1 text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-500 block mb-0.5">Actual Spent (m)</label>
                        <input
                          type="number"
                          value={manualActual}
                          onChange={(e) => setManualActual(Number(e.target.value))}
                          className="w-full bg-white border border-slate-200 rounded-lg p-1 text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-500 block mb-0.5">Add Tag</label>
                        <input
                          type="text"
                          value={manualKeyword}
                          onChange={(e) => setManualKeyword(e.target.value)}
                          placeholder="High Focus"
                          className="w-full bg-white border border-slate-200 rounded-lg p-1 text-xs"
                        />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Chat Adjustment AI Option */}
        <div className="bg-indigo-50/70 border border-indigo-200/80 rounded-2xl p-3.5 space-y-2 mt-2">
          <h5 className="text-xs font-bold text-indigo-900 flex items-center gap-1.5">
            <MessageSquare className="w-3.5 h-3.5 text-indigo-600" /> Adjust Values in AI Chat Box
          </h5>
          <div className="flex gap-2">
            <input
              type="text"
              value={aiCustomPrompt}
              onChange={(e) => setAiCustomPrompt(e.target.value)}
              placeholder='e.g. "Set actual time spent on final proposal to 45 minutes"'
              className="flex-1 bg-white border border-indigo-200 text-xs text-slate-800 rounded-xl px-3 py-2 outline-none"
            />
            <button
              onClick={handleSendAiPrompt}
              className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-3 py-2 rounded-xl transition-colors shrink-0"
            >
              Ask AI
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
