import React, { useEffect, useState } from 'react';
import { Bell, CheckCircle2, MessageSquare, X } from 'lucide-react';
import { SystemNotification } from '../types';

interface AndroidShadeNotificationProps {
  notifications: SystemNotification[];
  onDismiss: (id: string) => void;
  onOpenTask?: (taskId: string) => void;
}

export const AndroidShadeNotification: React.FC<AndroidShadeNotificationProps> = ({
  notifications,
  onDismiss,
  onOpenTask,
}) => {
  const unread = notifications.filter((n) => !n.read);

  if (unread.length === 0) return null;

  return (
    <div className="fixed top-2 left-1/2 -translate-x-1/2 z-50 w-[92%] max-w-md space-y-2 pointer-events-none">
      {unread.slice(-2).map((n) => (
        <div
          key={n.id}
          className="pointer-events-auto bg-slate-900/95 backdrop-blur-md text-white rounded-2xl p-3.5 shadow-2xl border border-slate-700/50 transition-all duration-300 animate-slide-down flex items-start gap-3"
        >
          <div className="p-2 rounded-xl bg-blue-600/30 text-blue-400 shrink-0">
            {n.type === 'task_reminder' ? (
              <CheckCircle2 className="w-5 h-5" />
            ) : (
              <MessageSquare className="w-5 h-5" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-semibold tracking-wider text-blue-400 uppercase">
                Productivity Assistant • Android System
              </span>
              <span className="text-[10px] text-slate-400">{n.timestamp}</span>
            </div>
            <h4 className="text-sm font-semibold text-slate-100 truncate mt-0.5">{n.title}</h4>
            <p className="text-xs text-slate-300 line-clamp-2 mt-0.5">{n.message}</p>

            {n.taskId && onOpenTask && (
              <button
                onClick={() => {
                  onOpenTask(n.taskId!);
                  onDismiss(n.id);
                }}
                className="mt-2 text-xs font-medium text-blue-400 hover:text-blue-300 transition-colors inline-flex items-center gap-1"
              >
                View Task Details →
              </button>
            )}
          </div>
          <button
            onClick={() => onDismiss(n.id)}
            className="text-slate-400 hover:text-slate-200 p-1 shrink-0 rounded-lg"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
};
