import React, { useState, useEffect } from 'react';
import {
  MessageSquare,
  CheckSquare,
  Users,
  BarChart3,
  Bell,
  Wifi,
  Battery,
  Signal,
  Clock,
  Sparkles,
} from 'lucide-react';
import {
  Task,
  Person,
  ChatMessage,
  SystemNotification,
  AppSettings,
  UrgencyLevel,
  ChatSession,
} from './types';
import {
  loadTasks,
  saveTasks,
  loadPeople,
  savePeople,
  saveChatMessages,
  loadInitialChatState,
  saveSessions,
  getFreshWelcomeMessage,
  loadNotifications,
  saveNotifications,
  loadSettings,
  saveSettings,
  getRandomAvatarColor,
  calculateDynamicUrgency,
} from './utils/storage';

import { ChatView } from './components/ChatView';
import { TaskListView } from './components/TaskListView';
import { TaskDetailModal } from './components/TaskDetailModal';
import { PeopleView } from './components/PeopleView';
import { PersonDetailModal } from './components/PersonDetailModal';
import { AnalyticsView } from './components/AnalyticsView';
import { RemindersSettingsView } from './components/RemindersSettingsView';
import { AndroidShadeNotification } from './components/AndroidShadeNotification';
import { MergeDuplicatesModal } from './components/MergeDuplicatesModal';
import {
  findDuplicateCandidates,
  executeTaskMerge,
  executePersonMerge,
  executeTagMerge,
} from './utils/deduplication';

type TabType = 'chat' | 'tasks' | 'people' | 'analytics' | 'settings';

export default function App() {
  // Application State initialized from localStorage & depurated for session history
  const [tasks, setTasks] = useState<Task[]>(() => loadTasks());
  const [people, setPeople] = useState<Person[]>(() => loadPeople());
  
  const [chatInit] = useState(() => loadInitialChatState());
  const [sessions, setSessions] = useState<ChatSession[]>(chatInit.sessions);
  const [messages, setMessages] = useState<ChatMessage[]>(chatInit.activeMessages);
  const [currentSessionId, setCurrentSessionId] = useState<string>(`session-${Date.now()}`);

  const [notifications, setNotifications] = useState<SystemNotification[]>(() => loadNotifications());
  // Ensure Crisis Helpline Banner is ALWAYS set as ON by default in fresh app sessions
  const [settings, setSettings] = useState<AppSettings>(() => {
    const loaded = loadSettings();
    return { ...loaded, safetyHelplineBannerEnabled: true };
  });

  // Active tab & modal states
  const [activeTab, setActiveTab] = useState<TabType>('chat');
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [selectedPerson, setSelectedPerson] = useState<Person | null>(null);
  const [showDuplicatesModal, setShowDuplicatesModal] = useState(false);
  const [hasActiveSafetyAlert, setHasActiveSafetyAlert] = useState(false);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [duplicateToastInfo, setDuplicateToastInfo] = useState<{
    show: boolean;
    count: number;
    autoMerged: number;
  }>({ show: false, count: 0, autoMerged: 0 });

  // Status bar time & simulated time machine state
  const [simulatedOffsetMs, setSimulatedOffsetMs] = useState<number>(0);
  const [currentTime, setCurrentTime] = useState('');

  useEffect(() => {
    const updateClock = () => {
      const simNow = new Date(Date.now() + simulatedOffsetMs);
      setCurrentTime(
        simNow.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateClock();
    const interval = setInterval(updateClock, 10000);
    return () => clearInterval(interval);
  }, [simulatedOffsetMs]);

  // Save changes to localStorage
  useEffect(() => {
    saveTasks(tasks);
  }, [tasks]);

  useEffect(() => {
    savePeople(people);
  }, [people]);

  useEffect(() => {
    saveSessions(sessions);
  }, [sessions]);

  // Helper to archive active session into sessions array if it contains user messages
  const archiveCurrentSessionIfNeeded = (currentMsgs: ChatMessage[], sessionList: ChatSession[], activeId: string) => {
    const userMsgs = currentMsgs.filter((m) => m.role === 'user');
    if (userMsgs.length === 0) return sessionList;

    const firstUserMsg = userMsgs[0];
    const title = firstUserMsg.content.slice(0, 36) + (firstUserMsg.content.length > 36 ? '...' : '');

    const currentSessionObj: ChatSession = {
      id: activeId,
      title,
      createdAt: new Date().toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
      messages: currentMsgs,
    };

    const existingIdx = sessionList.findIndex((s) => s.id === activeId);
    if (existingIdx !== -1) {
      const updated = [...sessionList];
      updated[existingIdx] = currentSessionObj;
      return updated;
    } else {
      return [currentSessionObj, ...sessionList];
    }
  };

  useEffect(() => {
    saveChatMessages(messages);
    if (messages.some((m) => m.role === 'user')) {
      setSessions((prev) => archiveCurrentSessionIfNeeded(messages, prev, currentSessionId));
    }
  }, [messages, currentSessionId]);

  useEffect(() => {
    saveNotifications(notifications);
  }, [notifications]);

  useEffect(() => {
    saveSettings(settings);
  }, [settings]);

  // Session History Management
  const handleStartNewChat = () => {
    setSessions((prev) => archiveCurrentSessionIfNeeded(messages, prev, currentSessionId));
    const newMsgs = getFreshWelcomeMessage(tasks, people);
    setMessages(newMsgs);
    setCurrentSessionId(`session-${Date.now()}`);
  };

  const handleSelectSession = (selectedSession: ChatSession) => {
    setSessions((prev) => archiveCurrentSessionIfNeeded(messages, prev, currentSessionId));
    setMessages(selectedSession.messages);
    setCurrentSessionId(selectedSession.id);
  };

  const handleDeleteSession = (sessionId: string) => {
    setSessions((prev) => prev.filter((s) => s.id !== sessionId));
  };

  // Perform background deduplication scan right after user sends message
  const runBackgroundDeduplicationScan = (latestTasks: Task[], latestPeople: Person[]) => {
    const candidates = findDuplicateCandidates(latestTasks, latestPeople);
    if (candidates.length === 0) return;

    let currentTasks = [...latestTasks];
    let currentPeople = [...latestPeople];
    let autoMergedCount = 0;

    candidates.forEach((cand) => {
      if (cand.type === 'tag') {
        currentTasks = executeTagMerge(currentTasks, cand.tagDuplicate, cand.tagCanonical);
        autoMergedCount++;
      } else if (cand.type === 'task') {
        const t1 = cand.olderTask;
        const t2 = cand.newerTask;
        const isExactTitle = t1.title.trim().toLowerCase() === t2.title.trim().toLowerCase();
        const hasUrgencyConflict = t1.urgency !== t2.urgency && t1.urgency && t2.urgency;

        if (isExactTitle && !hasUrgencyConflict) {
          const merged = executeTaskMerge(t1, t2);
          currentTasks = currentTasks
            .filter((t) => t.id !== t1.id)
            .map((t) => (t.id === t2.id ? merged : t));
          autoMergedCount++;
        }
      } else if (cand.type === 'person') {
        const p1 = cand.olderPerson;
        const p2 = cand.newerPerson;
        const isExactName = p1.name.trim().toLowerCase() === p2.name.trim().toLowerCase();

        if (isExactName) {
          const merged = executePersonMerge(p1, p2);
          currentPeople = currentPeople
            .filter((p) => p.id !== p1.id)
            .map((p) => (p.id === p2.id ? merged : p));

          currentTasks = currentTasks.map((t) => {
            if (t.involvedPeopleIds?.includes(p1.id)) {
              return {
                ...t,
                involvedPeopleIds: Array.from(
                  new Set([...t.involvedPeopleIds.filter((id) => id !== p1.id), p2.id])
                ),
              };
            }
            return t;
          });
          autoMergedCount++;
        }
      }
    });

    if (autoMergedCount > 0) {
      setTasks(currentTasks);
      setPeople(currentPeople);
    }

    const remainingCandidates = findDuplicateCandidates(currentTasks, currentPeople);
    if (remainingCandidates.length > 0 || autoMergedCount > 0) {
      setDuplicateToastInfo({
        show: true,
        count: remainingCandidates.length,
        autoMerged: autoMergedCount,
      });
    }
  };

  // Handler to send a chat message to the server API
  const handleSendMessage = async (text: string) => {
    const userMsgId = `usr-${Date.now()}`;
    const timestampStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const newUserMsg: ChatMessage = {
      id: userMsgId,
      role: 'user',
      content: text,
      timestamp: timestampStr,
    };

    const updatedMessages = [...messages, newUserMsg];
    setMessages(updatedMessages);
    setIsAiLoading(true);

    // Immediate background duplicate scan right after message send
    setTimeout(() => {
      runBackgroundDeduplicationScan(tasks, people);
    }, 100);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: updatedMessages.map((m) => ({ role: m.role, content: m.content })),
          userTasks: tasks,
          userPeople: people,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to connect to AI Task server');
      }

      const data = await response.json();

      if (data.isSafetyAlert) {
        setHasActiveSafetyAlert(true);
        // Reset Crisis Helpline Support Banner back to enabled whenever a new safety alert is triggered
        setSettings((prev) => ({ ...prev, safetyHelplineBannerEnabled: true }));
      }

      // Process extracted & updated tasks (validation & deduplication)
      const createdTaskIds: string[] = [];
      const updatedTaskIds: string[] = [];
      let updatedTasksList = [...tasks];

      if (data.extractedTasks && Array.isArray(data.extractedTasks) && data.extractedTasks.length > 0) {
        data.extractedTasks.forEach((extTask: any) => {
          // Resolve matched people (by name or alias, case insensitive)
          const matchedPeopleIds: string[] = [];
          if (extTask.involvedPeopleNames && Array.isArray(extTask.involvedPeopleNames)) {
            extTask.involvedPeopleNames.forEach((name: string) => {
              if (!name?.trim()) return;
              const cleanName = name.trim().toLowerCase();
              let existingP = people.find(
                (p) =>
                  p.name.toLowerCase() === cleanName ||
                  p.aliases?.some((alias) => alias.toLowerCase() === cleanName)
              );
              if (!existingP) {
                existingP = {
                  id: `person-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
                  name: name.trim(),
                  roleOrRelation: 'Contact',
                  avatarColor: getRandomAvatarColor(),
                  notes: `Added from task "${extTask.title}"`,
                  createdAt: new Date().toISOString(),
                };
                setPeople((prev) => [...prev, existingP!]);
              }
              matchedPeopleIds.push(existingP.id);
            });
          }

          // Check if AI validated an existing task to update
          const isUpdate = extTask.action === 'update' && extTask.existingTaskId;
          const existingIdx = isUpdate ? updatedTasksList.findIndex((t) => t.id === extTask.existingTaskId) : -1;

          if (isUpdate && existingIdx !== -1) {
            // UPDATE EXISTING TASK ON FILE
            const existingTask = updatedTasksList[existingIdx];

            // Merge unique notes/bullets
            const existingBullets = new Set(existingTask.notesBullets || []);
            if (extTask.notesBullets && Array.isArray(extTask.notesBullets)) {
              extTask.notesBullets.forEach((b: string) => existingBullets.add(b));
            }

            // Merge involved people
            const mergedPeopleIds = Array.from(
              new Set([...(existingTask.involvedPeopleIds || []), ...matchedPeopleIds])
            );

            // Merge emotional keywords
            const mergedEmotion = Array.from(
              new Set([...(existingTask.emotionalKeywords || []), ...(extTask.emotionalCategory || [])])
            );

            const updatedTaskObj: Task = {
              ...existingTask,
              title: extTask.title || existingTask.title,
              urgency: (extTask.urgency as UrgencyLevel) || existingTask.urgency,
              completed: typeof extTask.completed === 'boolean' ? extTask.completed : existingTask.completed,
              completedAt: extTask.completed ? (existingTask.completedAt || new Date().toISOString()) : (extTask.completed === false ? null : existingTask.completedAt),
              dueDateTime: extTask.dueDateTime !== undefined ? extTask.dueDateTime : existingTask.dueDateTime,
              environmentalCategory: extTask.environmentalCategory || existingTask.environmentalCategory,
              intendedTimeMinutes: extTask.intendedTimeMinutes || existingTask.intendedTimeMinutes,
              actualTimeMinutes: extTask.actualTimeMinutes !== null && extTask.actualTimeMinutes !== undefined ? extTask.actualTimeMinutes : existingTask.actualTimeMinutes,
              notesBullets: Array.from(existingBullets),
              involvedPeopleIds: mergedPeopleIds,
              emotionalKeywords: mergedEmotion.length > 0 ? mergedEmotion : existingTask.emotionalKeywords,
              followUpFrequency: extTask.followUpFrequency || existingTask.followUpFrequency,
            };

            updatedTasksList[existingIdx] = updatedTaskObj;
            updatedTaskIds.push(existingTask.id);

            if (settings.globalNotificationsEnabled) {
              triggerNotification(
                `Task Updated on File: ${updatedTaskObj.title}`,
                `Modified details • Urgency: ${updatedTaskObj.urgency}`,
                updatedTaskObj.id
              );
            }
          } else {
            // CREATE NEW TASK ON FILE
            const newTaskId = `task-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
            const newTaskObj: Task = {
              id: newTaskId,
              title: extTask.title || 'Untitled Task',
              completed: !!extTask.completed,
              urgency: (extTask.urgency as UrgencyLevel) || 'Medium',
              createdAt: new Date().toISOString(),
              dueDateTime: extTask.dueDateTime || null,
              emotionalKeywords: extTask.emotionalCategory || ['Focus'],
              environmentalCategory: extTask.environmentalCategory || 'Work',
              intendedTimeMinutes: extTask.intendedTimeMinutes || 30,
              actualTimeMinutes: extTask.actualTimeMinutes || 0,
              notesBullets: extTask.notesBullets || [],
              involvedPeopleIds: matchedPeopleIds,
              followUpFrequency: extTask.followUpFrequency || 'auto',
              notificationsEnabled: true,
              reminders: extTask.reminders || [
                {
                  id: `rem-${Date.now()}`,
                  label: 'Task Reminder',
                  triggerTime: extTask.dueDateTime || 'Today',
                  type: 'notification',
                  sent: false,
                },
              ],
            };

            updatedTasksList.push(newTaskObj);
            createdTaskIds.push(newTaskId);

            if (settings.globalNotificationsEnabled) {
              triggerNotification(
                `Task Logged: ${newTaskObj.title}`,
                `Assigned Urgency: ${newTaskObj.urgency} • ${newTaskObj.environmentalCategory}`,
                newTaskObj.id
              );
            }
          }
        });

        setTasks(updatedTasksList);
      }

      // Process extracted people with case-insensitive matching & non-repeating profile notes
      const extractedPeopleIds: string[] = [];
      if (data.extractedPeople && Array.isArray(data.extractedPeople) && data.extractedPeople.length > 0) {
        data.extractedPeople.forEach((extP: any) => {
          if (!extP.name) return;
          const searchName = extP.name.trim().toLowerCase();
          
          let pObj = people.find(
            (p) =>
              p.name.toLowerCase() === searchName ||
              p.aliases?.some((a) => a.toLowerCase() === searchName)
          );

          if (!pObj) {
            pObj = {
              id: `person-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
              name: extP.name.trim(),
              roleOrRelation: extP.roleOrRelation || 'Contact',
              avatarColor: getRandomAvatarColor(),
              notes: extP.notes || '',
              aliases: extP.aliases || [],
              createdAt: new Date().toISOString(),
            };
            setPeople((prev) => [...prev, pObj!]);
          } else {
            // Update existing person profile - ensuring notes are NOT repeated
            const existingNotes = pObj.notes || '';
            const newNoteText = extP.notes?.trim() || '';
            
            // Only append new note if it's non-empty and not already included in existing notes
            let mergedNotes = existingNotes;
            if (newNoteText && !existingNotes.toLowerCase().includes(newNoteText.toLowerCase())) {
              mergedNotes = existingNotes ? `${existingNotes}\n• ${newNoteText}` : newNoteText;
            }

            // Merge aliases without duplicates
            const mergedAliases = Array.from(
              new Set([...(pObj.aliases || []), ...(extP.aliases || [])])
            );

            setPeople((prev) =>
              prev.map((p) =>
                p.id === pObj!.id
                  ? {
                      ...p,
                      roleOrRelation: extP.roleOrRelation || p.roleOrRelation,
                      notes: mergedNotes,
                      aliases: mergedAliases,
                    }
                  : p
              )
            );
          }
          extractedPeopleIds.push(pObj.id);
        });
      }

      // Append Assistant Message
      const assistantMsg: ChatMessage = {
        id: `ast-${Date.now()}`,
        role: 'assistant',
        content: data.replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isOffTopic: data.isOffTopic,
        isSafetyAlert: data.isSafetyAlert,
        suggestedRephrase: data.suggestedRephrase,
        refiningQuestion: data.refiningQuestion,
        extractedTaskIds: createdTaskIds.length > 0 ? createdTaskIds : undefined,
        updatedTaskIds: updatedTaskIds.length > 0 ? updatedTaskIds : undefined,
        extractedPeopleIds: extractedPeopleIds.length > 0 ? extractedPeopleIds : undefined,
      };

      setMessages((prev) => [...prev, assistantMsg]);

      // Run background deduplication scan on newly updated tasks & people
      setTimeout(() => {
        runBackgroundDeduplicationScan(updatedTasksList, people);
      }, 200);
    } catch (err: any) {
      console.error('AI chat error:', err);
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'assistant',
        content:
          'I ran into an issue connecting to Violet AI. Please check your network or try rephrasing.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsAiLoading(false);
    }
  };

  // Trigger system notification banner
  const triggerNotification = (title: string, message: string, taskId?: string) => {
    if (!settings.globalNotificationsEnabled) return;
    const newNotif: SystemNotification = {
      id: `notif-${Date.now()}`,
      title,
      message,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      read: false,
      type: 'task_reminder',
      taskId,
    };
    setNotifications((prev) => [...prev, newNotif]);
  };

  const handleDismissNotification = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  // Task actions
  const handleToggleTaskComplete = (taskId: string) => {
    const currentRefTime = Date.now() + simulatedOffsetMs;
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id !== taskId) return t;
        const nextCompleted = !t.completed;
        const currentUrgency = calculateDynamicUrgency(t, currentRefTime);
        const isPastDue = currentUrgency === 'Past Due' || (t.dueDateTime && new Date(t.dueDateTime).getTime() < currentRefTime);

        return {
          ...t,
          completed: nextCompleted,
          completedAt: nextCompleted ? new Date(currentRefTime).toISOString() : null,
          completedPastDue: nextCompleted ? (isPastDue || Boolean(t.completedPastDue)) : t.completedPastDue,
        };
      })
    );
  };

  const handleToggleTaskNotification = (taskId: string) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, notificationsEnabled: !t.notificationsEnabled } : t))
    );
  };

  const handleUpdateTask = (updatedTask: Task) => {
    setTasks((prev) => prev.map((t) => (t.id === updatedTask.id ? updatedTask : t)));
  };

  const handleDeleteTask = (taskId: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== taskId));
    setSelectedTask(null);
  };

  const handleAddNewTask = (newTaskData: Partial<Task>) => {
    const newTaskObj: Task = {
      id: `task-${Date.now()}`,
      title: newTaskData.title || 'New Task',
      completed: false,
      urgency: newTaskData.urgency || 'Medium',
      createdAt: new Date().toISOString(),
      dueDateTime: newTaskData.dueDateTime || null,
      emotionalKeywords: newTaskData.emotionalKeywords || ['Focus'],
      environmentalCategory: newTaskData.environmentalCategory || 'Work',
      intendedTimeMinutes: newTaskData.intendedTimeMinutes || 30,
      actualTimeMinutes: 0,
      notesBullets: newTaskData.notesBullets || [],
      involvedPeopleIds: newTaskData.involvedPeopleIds || [],
      followUpFrequency: newTaskData.followUpFrequency || 'auto',
      notificationsEnabled: true,
      reminders: [],
    };
    setTasks((prev) => [newTaskObj, ...prev]);
  };

  // People actions
  const handleUpdatePerson = (updatedPerson: Person) => {
    setPeople((prev) => prev.map((p) => (p.id === updatedPerson.id ? updatedPerson : p)));
  };

  const handleDeletePerson = (personId: string) => {
    setPeople((prev) => prev.filter((p) => p.id !== personId));
    setSelectedPerson(null);
  };

  const handleAddNewPerson = (newPersonData: Partial<Person>): Person => {
    const newPersonObj: Person = {
      id: `person-${Date.now()}`,
      name: newPersonData.name || 'New Person',
      roleOrRelation: newPersonData.roleOrRelation || 'Contact',
      avatarColor: newPersonData.avatarColor || getRandomAvatarColor(),
      email: newPersonData.email,
      phone: newPersonData.phone,
      notes: newPersonData.notes || '',
      aliases: newPersonData.aliases || [],
      createdAt: new Date().toISOString(),
    };
    setPeople((prev) => [...prev, newPersonObj]);
    return newPersonObj;
  };

  const handleResetAllData = () => {
    const freshTasks = loadTasks();
    const freshPeople = loadPeople();
    const freshInit = loadInitialChatState();
    const freshNotifs = loadNotifications();
    const freshSettings = loadSettings();

    setTasks(freshTasks);
    setPeople(freshPeople);
    setSessions(freshInit.sessions);
    setMessages(freshInit.activeMessages);
    setCurrentSessionId(`session-${Date.now()}`);
    setNotifications(freshNotifs);
    setSettings(freshSettings);
    setSelectedTask(null);
    setSelectedPerson(null);
    setHasActiveSafetyAlert(false);
    setActiveTab('chat');
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-0 sm:p-4 select-none font-sans">
      {/* Android Device Frame */}
      <div className="w-full sm:w-[410px] h-screen sm:h-[840px] bg-slate-900 sm:rounded-[48px] shadow-2xl border-0 sm:border-[10px] border-slate-800 overflow-hidden flex flex-col relative">
        {/* Top Camera Notch / Bar */}
        <div className="bg-slate-900 px-6 pt-3 pb-1 flex items-center justify-between text-white shrink-0 z-40">
          <div className="flex items-center gap-1">
            <span className="text-xs font-bold tracking-tight">{currentTime || '12:00'}</span>
            {simulatedOffsetMs > 0 && (
              <span className="text-[10px] text-amber-400 font-bold bg-amber-950 px-1 rounded border border-amber-700/60" title="Simulated Time Active">
                +{Math.round(simulatedOffsetMs / (1000 * 60 * 60 * 24))}d
              </span>
            )}
          </div>
          <div className="w-16 h-4 bg-slate-950 rounded-full mx-auto hidden sm:block"></div>
          <div className="flex items-center gap-1.5 text-xs text-slate-300">
            <Signal className="w-3.5 h-3.5" />
            <Wifi className="w-3.5 h-3.5" />
            <Battery className="w-4 h-4 text-emerald-400" />
          </div>
        </div>

        {/* Real-time Android Shade System Notifications */}
        <AndroidShadeNotification
          notifications={notifications}
          onDismiss={handleDismissNotification}
          onOpenTask={(tid) => {
            const found = tasks.find((t) => t.id === tid);
            if (found) setSelectedTask(found);
          }}
        />

        {/* Main App Container */}
        <div className="flex-1 bg-slate-50 overflow-hidden flex flex-col relative">
          {activeTab === 'chat' && (
            <ChatView
              messages={messages}
              onSendMessage={handleSendMessage}
              isLoading={isAiLoading}
              onNavigateToTask={(tid) => {
                const found = tasks.find((t) => t.id === tid);
                if (found) setSelectedTask(found);
              }}
              onNavigateToPerson={(pid) => {
                const found = people.find((p) => p.id === pid);
                if (found) setSelectedPerson(found);
              }}
              tasks={tasks}
              people={people}
              sessions={sessions}
              currentSessionId={currentSessionId}
              onStartNewChat={handleStartNewChat}
              onSelectSession={handleSelectSession}
              onDeleteSession={handleDeleteSession}
              onOpenDuplicatesModal={() => setShowDuplicatesModal(true)}
              hasActiveSafetyAlert={hasActiveSafetyAlert}
              safetyHelplineBannerEnabled={settings.safetyHelplineBannerEnabled}
              duplicateToastInfo={duplicateToastInfo}
              onDismissDuplicateToast={() => setDuplicateToastInfo((prev) => ({ ...prev, show: false }))}
            />
          )}

          {activeTab === 'tasks' && (
            <TaskListView
              tasks={tasks}
              people={people}
              onSelectTask={(task) => setSelectedTask(task)}
              onToggleComplete={handleToggleTaskComplete}
              onToggleNotification={handleToggleTaskNotification}
              onAddNewTask={handleAddNewTask}
              onAddNewPerson={handleAddNewPerson}
              simulatedOffsetMs={simulatedOffsetMs}
            />
          )}

          {activeTab === 'people' && (
            <PeopleView
              people={people}
              tasks={tasks}
              onSelectPerson={(person) => setSelectedPerson(person)}
              onAddNewPerson={handleAddNewPerson}
            />
          )}

          {activeTab === 'analytics' && (
            <AnalyticsView
              tasks={tasks}
              onUpdateTask={handleUpdateTask}
              onSendChatMessage={(prompt) => {
                setActiveTab('chat');
                handleSendMessage(prompt);
              }}
            />
          )}

          {activeTab === 'settings' && (
            <RemindersSettingsView
              settings={settings}
              tasks={tasks}
              notifications={notifications}
              onUpdateSettings={setSettings}
              onTriggerTestNotification={triggerNotification}
              onSendChatMessage={(prompt) => {
                setActiveTab('chat');
                handleSendMessage(prompt);
              }}
              onResetAllData={handleResetAllData}
              onOpenDuplicatesModal={() => setShowDuplicatesModal(true)}
              simulatedOffsetMs={simulatedOffsetMs}
              onFastForwardTime={(addMs) => setSimulatedOffsetMs((prev) => prev + addMs)}
              onResetSimulatedTime={() => setSimulatedOffsetMs(0)}
            />
          )}
        </div>

        {/* Review & Merge Duplicates Modal */}
        {showDuplicatesModal && (
          <MergeDuplicatesModal
            tasks={tasks}
            people={people}
            onClose={() => setShowDuplicatesModal(false)}
            onUpdateTasks={setTasks}
            onUpdatePeople={setPeople}
          />
        )}

        {/* Task Detail Modal */}
        {selectedTask && (
          <TaskDetailModal
            task={selectedTask}
            people={people}
            onClose={() => setSelectedTask(null)}
            onUpdateTask={handleUpdateTask}
            onDeleteTask={handleDeleteTask}
            onAddNewPerson={handleAddNewPerson}
          />
        )}

        {/* Person Detail Modal */}
        {selectedPerson && (
          <PersonDetailModal
            person={selectedPerson}
            tasks={tasks}
            onClose={() => setSelectedPerson(null)}
            onUpdatePerson={handleUpdatePerson}
            onDeletePerson={handleDeletePerson}
            onOpenTask={(tid) => {
              const found = tasks.find((t) => t.id === tid);
              if (found) setSelectedTask(found);
            }}
            onSendChatMessage={(prompt) => {
              setActiveTab('chat');
              handleSendMessage(prompt);
            }}
          />
        )}

        {/* Bottom Android Navigation Bar */}
        <div className="bg-white border-t border-slate-200 px-2 py-2 flex items-center justify-around shrink-0 z-40">
          <button
            onClick={() => setActiveTab('chat')}
            className={`flex flex-col items-center gap-1 px-3 py-1 rounded-2xl transition-all cursor-pointer ${
              activeTab === 'chat'
                ? 'text-violet-600 bg-violet-50 font-bold'
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <MessageSquare className="w-5 h-5" />
            <span className="text-[10px]">AI Chat</span>
          </button>

          <button
            onClick={() => setActiveTab('tasks')}
            className={`flex flex-col items-center gap-1 px-3 py-1 rounded-2xl transition-all cursor-pointer relative ${
              activeTab === 'tasks'
                ? 'text-violet-600 bg-violet-50 font-bold'
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <CheckSquare className="w-5 h-5" />
            <span className="text-[10px]">To-Do</span>
            {tasks.filter((t) => !t.completed).length > 0 && (
              <span className="absolute top-1 right-2 w-2 h-2 rounded-full bg-violet-600"></span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('people')}
            className={`flex flex-col items-center gap-1 px-3 py-1 rounded-2xl transition-all cursor-pointer ${
              activeTab === 'people'
                ? 'text-violet-600 bg-violet-50 font-bold'
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <Users className="w-5 h-5" />
            <span className="text-[10px]">People</span>
          </button>

          <button
            onClick={() => setActiveTab('analytics')}
            className={`flex flex-col items-center gap-1 px-3 py-1 rounded-2xl transition-all cursor-pointer ${
              activeTab === 'analytics'
                ? 'text-violet-600 bg-violet-50 font-bold'
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <BarChart3 className="w-5 h-5" />
            <span className="text-[10px]">Analytics</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex flex-col items-center gap-1 px-3 py-1 rounded-2xl transition-all cursor-pointer ${
              activeTab === 'settings'
                ? 'text-violet-600 bg-violet-50 font-bold'
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <Bell className="w-5 h-5" />
            <span className="text-[10px]">Reminders</span>
          </button>
        </div>

        {/* Gesture Indicator Bar */}
        <div className="bg-white pb-1 flex justify-center shrink-0">
          <div className="w-32 h-1 bg-slate-300 rounded-full"></div>
        </div>
      </div>
    </div>
  );
}
